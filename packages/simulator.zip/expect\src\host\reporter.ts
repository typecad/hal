// ---------------------------------------------------------------------------
// @typecode/expect — Vitest-style console reporter
//
// Renders test results to the console with ANSI colors, mimicking vitest's
// output format.
//
// Example output:
//
//  typecode-test v0.1.0
//
//  ✓ A0 analog read (2 tests)
//    ✓ reads zero when grounded          2ms
//    ✓ reads less than 100               1ms
//
//  ✗ Temperature sensor (1 of 2 failing)
//    ✓ reads above freezing              3ms
//    ✗ reads room temperature            2ms
//
//      expect(actual).toBeWithinRange(20, 25)
//      Actual:   31
//      Expected: 20–25
//
//  Tests   3 passed | 1 failed (4)
//  Board   Arduino Uno @ COM3
//  Time    8.42s
// ---------------------------------------------------------------------------

import type { RunResult, FileResult, DescribeResult, TestResult, AssertionResult } from './types';
import { describeExpected } from './evaluator';

// ---------------------------------------------------------------------------
// ANSI color codes
// ---------------------------------------------------------------------------

const RESET     = '\x1b[0m';
const BOLD      = '\x1b[1m';
const DIM       = '\x1b[2m';
const RED       = '\x1b[31m';
const GREEN     = '\x1b[32m';
const YELLOW    = '\x1b[33m';
const CYAN      = '\x1b[36m';
const WHITE     = '\x1b[37m';
const RED_BG    = '\x1b[41m';
const GREEN_BG  = '\x1b[42m';

const PASS_ICON = `${GREEN}✓${RESET}`;
const FAIL_ICON = `${RED}✗${RESET}`;

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Print the complete test run result to stdout.
 */
export function reportResults(
  result: RunResult,
  options: { board?: string; port?: string; verbose?: boolean } = {},
): void {
  const { board, port, verbose } = options;

  // Header
  console.log();
  console.log(`${BOLD}${CYAN} typecode-test ${DIM}v0.1.0${RESET}`);
  console.log();

  // Per-file results
  for (const file of result.files) {
    reportFile(file, verbose ?? false);
  }

  // Failures detail
  const failures = collectFailures(result);
  if (failures.length > 0) {
    console.log(`${BOLD}${RED} FAILURES${RESET}`);
    console.log();
    for (const f of failures) {
      reportFailure(f);
    }
  }

  // Summary
  console.log();
  reportSummary(result, board, port);
  console.log();
}

// ---------------------------------------------------------------------------
// Internal — File reporting
// ---------------------------------------------------------------------------

function reportFile(file: FileResult, verbose: boolean): void {
  if (file.error) {
    console.log(` ${FAIL_ICON} ${BOLD}${file.filePath}${RESET} ${RED}(error)${RESET}`);
    console.log(`   ${DIM}${file.error}${RESET}`);
    console.log();
    return;
  }

  for (const desc of file.describes) {
    reportDescribe(desc, verbose);
  }

  // Debug output
  if (verbose && file.debugOutput.length > 0) {
    console.log(`   ${DIM}── serial debug ──${RESET}`);
    for (const line of file.debugOutput) {
      console.log(`   ${DIM}${line}${RESET}`);
    }
    console.log();
  }
}

function reportDescribe(desc: DescribeResult, verbose: boolean): void {
  const totalTests = desc.tests.length;
  const passedTests = desc.tests.filter(t => t.passed).length;
  const failedTests = totalTests - passedTests;

  const icon = desc.passed ? PASS_ICON : FAIL_ICON;
  const countText = desc.passed
    ? `${DIM}(${totalTests} test${totalTests !== 1 ? 's' : ''})${RESET}`
    : `${RED}(${failedTests} of ${totalTests} failing)${RESET}`;

  console.log(` ${icon} ${BOLD}${desc.name}${RESET} ${countText}`);

  for (const test of desc.tests) {
    reportTest(test, verbose);
  }

  console.log();
}

function reportTest(test: TestResult, verbose: boolean): void {
  const icon = test.passed ? PASS_ICON : FAIL_ICON;
  const duration = test.durationMs > 0 ? `${DIM}${test.durationMs}ms${RESET}` : '';
  console.log(`   ${icon} ${test.name}  ${duration}`);

  // In verbose mode, show passing assertion details too
  if (verbose && test.passed) {
    for (const a of test.assertions) {
      console.log(`     ${DIM}${a.matcher}(${a.expected}) → ${a.actual} ✓${RESET}`);
    }
  }
}

// ---------------------------------------------------------------------------
// Internal — Failure details
// ---------------------------------------------------------------------------

interface FailureInfo {
  describeName: string;
  testName: string;
  assertion: AssertionResult;
}

function collectFailures(result: RunResult): FailureInfo[] {
  const failures: FailureInfo[] = [];
  for (const file of result.files) {
    for (const desc of file.describes) {
      for (const test of desc.tests) {
        for (const assertion of test.assertions) {
          if (!assertion.passed) {
            failures.push({
              describeName: desc.name,
              testName: test.name,
              assertion,
            });
          }
        }
      }
    }
  }
  return failures;
}

function reportFailure(f: FailureInfo): void {
  const a = f.assertion;
  console.log(`   ${RED}${BOLD}${f.describeName} > ${f.testName}${RESET}`);
  console.log();
  console.log(`     ${DIM}expect(actual).${a.matcher}(${a.expected})${RESET}`);
  console.log(`     ${RED}Actual:   ${BOLD}${a.actual}${RESET}`);
  console.log(`     ${GREEN}Expected: ${BOLD}${describeExpected(a.matcher, a.expected)}${RESET}`);
  console.log();
}

// ---------------------------------------------------------------------------
// Internal — Summary
// ---------------------------------------------------------------------------

function reportSummary(
  result: RunResult,
  board?: string,
  port?: string,
): void {
  // Tests line
  const passedText = result.totalPassed > 0
    ? `${GREEN}${BOLD}${result.totalPassed} passed${RESET}`
    : '';
  const failedText = result.totalFailed > 0
    ? `${RED}${BOLD}${result.totalFailed} failed${RESET}`
    : '';

  const parts = [passedText, failedText].filter(Boolean).join(`${DIM} | ${RESET}`);
  const total = result.totalTests;
  console.log(` ${BOLD}Tests${RESET}   ${parts} ${DIM}(${total})${RESET}`);

  // Board line
  if (board || port) {
    const boardPart = board ?? 'unknown';
    const portPart = port ? ` @ ${port}` : '';
    console.log(` ${BOLD}Board${RESET}   ${boardPart}${portPart}`);
  }

  // Time line
  const seconds = (result.durationMs / 1000).toFixed(2);
  console.log(` ${BOLD}Time${RESET}    ${seconds}s`);

  // Final status bar
  if (result.totalFailed > 0) {
    console.log();
    console.log(`${RED_BG}${WHITE}${BOLD} FAIL ${RESET} ${RED}${result.totalFailed} test${result.totalFailed !== 1 ? 's' : ''} failed${RESET}`);
  } else {
    console.log();
    console.log(`${GREEN_BG}${WHITE}${BOLD} PASS ${RESET} ${GREEN}All tests passed${RESET}`);
  }
}
